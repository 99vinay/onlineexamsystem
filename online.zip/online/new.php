<!DOCTYPE html>
<html>
<head>
	
	<meta charset="UTF-8">
		<title>Online Exam Portal - Endeavor</title>               
		<!-- Latest compiled and minified CSS -->
<!-- Latest compiled and minified CSS -->
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
		<link rel="stylesheet" type="text/css" href="css/stylesheet.css">
		<script type="text/javascript"></script>
</head>
<body>
	<div class="container">
		 <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">Open Modal</button>

<div class="modal fade" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content title1">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title title1"><span style="color:orange"><textLog In</span></h4>
      </div>
      <div class="modal-body">
       <form action="" name="login" onsubmit="return validate();"method="post" style="padding-left:20px; padding-right:20px"><br><br>
                      <div class="form-group"><input class="form-control" type="text" name="username" placeholder="Username"></div><br>
                      <div class="form-group"><input class="form-control" type="password" name="password" placeholder="Password"></div><br><br>
                      <div class="form-group"><input class="form-control" type="submit" name="signin" value="Sign In"></div>
                    </form>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div>
</div><!-- /.modal -->
<!--sign in modal closed-->
</body>
</html>
