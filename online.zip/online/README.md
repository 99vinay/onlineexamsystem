# online-exam-portal
Online Exam Portal Using PHP, MYSQL, JQUERY, BOOTSTRAP

To run the project edit the database.php file according to your database settings and import the online_examv4.sql into you phpmyadmin. <br>
Administrator Username: admin <br>
Administrator Password: admin
