<!DOCTYPE html>
<html>
<head>
	<title>Online Exam</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="stylesheet" type="text/css" href="css/stylesheet.css">
		<script type="text/javascript" src="js/solveTest.js"></script>
</head>
<body>
	<div class="container" style="margin-top:50px;">
      
      <center><p>You haven't press the submit button thats why yours reasponses are not recorded</p></center>
      <table class="table">
        <thead>
          <tr>
            <th>Total Questions</th>
            <th>Correct Answers</th>
            <th>Wrong Answers</th>
            <th>Not Attempted</th>
            <th>Score</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td><h1>0</h1></td>
            <td><h1>0</h1></td>
            <td><h1>0</h1></td>
            <td><h1>0</h1></td>
            <td><h1>0</h1></td>
          </tr>
        </tbody>
      </table>
     
  </div>
 <script>

function closeWin() {
  alert("Press the Cross Mark to close the full window")
}

    </script>
</body>
</html>