<?php
$conn = mysqli_connect('localhost', 'id13425503_issha', '3(lnyRf|3--A{x~k', 'id13425503_online_examv4');
if(mysqli_connect_errno()){
        echo 'Failed to connect to MySQL '. mysqli_connect_errno();
    }
date_default_timezone_set('Asia/Kolkata');
?>
